export const environment = {
    production: true,
    apiServer: ''
};
