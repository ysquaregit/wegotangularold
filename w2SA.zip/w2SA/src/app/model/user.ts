export class User {
    constructor(name?: string, password?: string) {
    }
}
